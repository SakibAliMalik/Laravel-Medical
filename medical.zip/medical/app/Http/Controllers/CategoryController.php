<?php
namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }

	public function add()
    {
        return view('admin.add_category');
    }

    public function store(Request $request)
    {
        // Validate the request...

        $category = new Category;

        $category->cat_name = $request->category_name;

        $category->save();
    }

    public function list()
    {
        $categories = Category::all();

		return view('admin.list_category', compact('categories'));
	}

    public function cat_del(Request $request)
    {
        return view('admin.add_category');

    }
}