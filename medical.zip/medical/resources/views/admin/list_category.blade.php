<?php
foreach ($categories as $category) {
?>
<a href="{{route('admin.category.del',$category->id)}}"  data-id="{{$category->id}}">{{$category->cat_name}}</a><br>
<?php  } ?>