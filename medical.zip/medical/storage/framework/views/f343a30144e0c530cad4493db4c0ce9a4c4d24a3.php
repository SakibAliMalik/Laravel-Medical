<?php
foreach ($categories as $category) {
?>
<a href="<?php echo e(route('admin.category.del',$category->id)); ?>"  data-id="<?php echo e($category->id); ?>"><?php echo e($category->cat_name); ?></a><br>
<?php  } ?>